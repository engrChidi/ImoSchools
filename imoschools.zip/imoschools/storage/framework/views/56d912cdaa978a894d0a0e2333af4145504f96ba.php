<?php $__env->startSection('title'); ?>
School Registration
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">New School</li>
    </ol>
    <h1>Create a School</h1>

    <div class="alert alert-warning"> <!-- if there are creation errors, they will show here -->
        <?php echo e(Html::ul($errors->all())); ?>

    </div>
    <?php echo e(Form::open(array('route' => 'business.store','method'=>'POST'))); ?>


    <div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('userName', 'Name of Business Owner')); ?>

                <?php echo e(Form::text('userName', null, array('class' => 'form-control'))); ?>

            </div>
        </div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('businessName', 'Business Name')); ?>

                <?php echo e(Form::text('businessName', null, array('class' => 'form-control'))); ?>

            </div> </div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('product', 'Product/Services Offered')); ?>

                <?php echo e(Form::text('product', null, array('class' => 'form-control'))); ?>

            </div> </div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('location', 'Office Address')); ?>

                <?php echo e(Form::textarea('location', null, array('placeholder' => 'Subjects You Teach','class' => 'form-control','style'=>'color:blue'))); ?>

            </div></div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('image', 'Product Picture:')); ?>

                <?php echo e(Form::text('image', null, array('class'=>'form-control'))); ?>

            </div></div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('comment', 'Comment: (say something good about your Business)')); ?>

                <?php echo e(Form::text('comment', null, array('placeholder' => 'The Current Class You Teach','class' => 'form-control','style'=>'color:blue'))); ?>

            </div></div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('phone', 'Contact Phone: (separate with comma if more than one)')); ?>

                <?php echo e(Form::text('phone', null, array('class' => 'form-control'))); ?>

            </div></div>
        <div class="col-md-6">

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.businessMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>