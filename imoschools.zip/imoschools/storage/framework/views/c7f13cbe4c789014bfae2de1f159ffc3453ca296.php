<?php $__env->startSection('title'); ?>
Teacher Registration
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div class="pull-left">
        <h2>Academicians List</h2>
    </div>
    <div class="pull-right">
        <a class="btn btn-success" href="<?php echo e(route('rate.create')); ?>"> Create New Product</a>
    </div>



    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Rater</th>
            <th>RaterID</th>
            <th>Ratee</th>
            <th>RateeID</th>
            <th>Rate</th>
            <th>Comment</th>
            <th width="280px">Action</th>
        </tr>
        <?php foreach($rate as $rating): ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($rating->rater); ?></td>
                <td><?php echo e($rating->raterid); ?></td>
                <td><?php echo e($rating->ratee); ?></td>
                <td><?php echo e($rating->rateeid); ?></td>
                <td><?php echo e($rating->rate); ?></td>
                <td><?php echo e($rating->comment); ?></td>
                <td>
                    <a class="btn btn-info" href="<?php echo e(route('rate.show',$rating->id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('rate.edit',$rating->id)); ?>">Edit</a>
                    <?php echo e(Form::open(['method' => 'DELETE','route' => ['rate.destroy', $rating->id],'style'=>'display:inline'])); ?>

                    <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>


                    <?php echo e(Form::close()); ?>

                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <?php echo e($rate->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rateMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>