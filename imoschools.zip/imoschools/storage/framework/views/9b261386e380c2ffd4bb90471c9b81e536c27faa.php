<?php $__env->startSection('title'); ?>
School Registration
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">Display</li>
    </ol>
    <div class="row">

        <div class="col-lg-12 margin-tb">

            <div class="pull-left">

                <h2>Edit School</h2>

            </div>

        </div>

    </div>
    <?php if(count($errors) > 0): ?>

        <div class="alert alert-danger">

            <strong>Whoops!</strong> There were some problems with your input.<br><br>

            <ul> <?php foreach($errors->all() as $error): ?>

                    <li><?php echo e($error); ?></li>

                <?php endforeach; ?>

            </ul>

        </div>

    <?php endif; ?>
    <?php echo e(Form::model($students, ['method' => 'PATCH','route' => ['students.update', $students->id]])); ?>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>User Name:</strong>
                <?php echo e(Form::text('studentName', null, array('placeholder' => 'Title','class' => 'form-control'))); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Level:</strong>
                <?php echo e(Form::textarea('level', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px'))); ?>

            </div></div></div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Phone:</strong>
                <?php echo e(Form::text('phone', null, array('placeholder' => 'Title','class' => 'form-control'))); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Gender:</strong>
                <?php echo e(Form::textarea('gender', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px'))); ?>

            </div></div></div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Dob:</strong>
                <?php echo e(Form::text('dob', null, array('placeholder' => 'Title','class' => 'form-control'))); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>isID:</strong>
                <?php echo e(Form::textarea('isID', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px'))); ?>

            </div></div></div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>rate:</strong>
                <?php echo e(Form::text('rate', null, array('placeholder' => 'Title','class' => 'form-control'))); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-6">

            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.studentsMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>