<?php $__env->startSection('title'); ?>
    Display Schools
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <h2>Editing Schools</h2>
        <ol class="breadcrumb text-left">
            <li><a href="#">Home</a></li>
            <li><a href="#">Schools</a></li>
            <li class="active">Teachers</li>
        </ol>

        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('academics.index')); ?>"> Back</a>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Name:</strong>
                    <?php echo e($academics->userName); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Details:</strong>
                    <?php echo e($academics->phone); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Comment:</strong>
                    <?php echo e($academics->comment); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Subject:</strong>
                    <?php echo e($academics->subject); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Qualification:</strong>
                    <?php echo e($academics->qualification); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>LGA:</strong>
                    <?php echo e($academics->lga); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Upload Paper:</strong>
                    <?php echo e($academics->uploadQuestion); ?>

                </div>
            </div>
        </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academicMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>