<div class="row" style="background-color:black; color: #cccccc">
    <div class="col-md-3">
        <h3>
           Contac us/Partners
        </h3>
      Owerri Office:
        PH Office:
        Bayelsa Office:
        Lagos Office: 5 debisi Arandun Street, Iba Town, Ojo Lagos
    </div>
    <div class="col-md-3">
        <h3>
            Quick Links
        </h3>
     <a href="<?php echo e(route('schools.create')); ?>">  Register School</a>
       <a href="">Teacher</a>
        <h3>
            Examination Bodies
        </h3>
       <a href="https://waeconline.org"> west african examination council</a>
        <a href="https://jambonline.com"> admissions matriculation board</a>
       <a href="https://neco.com.ng"> national examinations council</a>

    </div>
    <div class="col-md-3">
        <h3>
           Downloads
        </h3>
        Lesson Plan

    </div><div class="col-md-3">
        <h3>
            Terms and Conditions
        </h3>
        Website Use Policy
        Privacy Policy
        Advert Policy

    </div>
</div>