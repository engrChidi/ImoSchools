<?php $__env->startSection('title'); ?>
Teacher Registration
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div class="pull-left">
        <h2>Academicians List</h2>
    </div>
    <div class="pull-right">
        <a class="btn btn-success" href="<?php echo e(route('academics.create')); ?>"> Create New Product</a>
    </div>



    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>TeacherName</th>
            <th>Phone</th>
            <th>Subjects</th>
            <th width="280px">Action</th>
        </tr>
        <?php foreach($academics as $academic): ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($academic->userName); ?></td>
                <td><?php echo e($academic->phone); ?></td>
                <td><?php echo e($academic->subject); ?></td>
                <td>
                    <a class="btn btn-info" href="<?php echo e(route('academics.show',$academic->id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('academics.edit',$academic->id)); ?>">Edit</a>
                    <?php echo e(Form::open(['method' => 'DELETE','route' => ['academics.destroy', $academic->id],'style'=>'display:inline'])); ?>

                    <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>


                    <?php echo e(Form::close()); ?>

                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <?php echo e($academics->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.academicMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>