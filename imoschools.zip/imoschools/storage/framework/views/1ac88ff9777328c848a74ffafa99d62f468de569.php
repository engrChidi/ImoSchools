<?php $__env->startSection('title'); ?>
School Registration
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">New School</li>
    </ol>
    <h1>Create a School</h1>

    <div class="alert alert-warning"> <!-- if there are creation errors, they will show here -->
        <?php echo e(Html::ul($errors->all())); ?>

    </div>
    <?php echo e(Form::open(array('route' => 'teachers.store','method'=>'POST'))); ?>


    <div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('teacherName', 'Teacher Name')); ?>

                <?php echo e(Form::text('teacherName', null, array('class' => 'form-control'))); ?>

            </div>
        </div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('phone', 'Phone Number')); ?>

                <?php echo e(Form::text('phone', null, array('class' => 'form-control'))); ?>

            </div> </div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('comment', 'Comment')); ?>

                <?php echo e(Form::text('comment', null, array('class' => 'form-control'))); ?>

            </div> </div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('subjects', 'Subjects: (Separate with Comma?)')); ?>

                <?php echo e(Form::text('subjects', null, array('placeholder' => 'Subjects You Teach','class' => 'form-control','style'=>'color:blue'))); ?>

            </div></div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('gender', 'Gender:')); ?>

                <?php echo e(Form::select('gender', ['Male','Female'], null, array('class'=>'form-control'))); ?>

            </div></div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('currentclass', 'Class your Teacher: (e.g SS# or SS1A)')); ?>

                <?php echo e(Form::text('currentclass', null, array('placeholder' => 'The Current Class You Teach','class' => 'form-control','style'=>'color:blue'))); ?>

            </div></div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('isID', 'School ID: (view list of schools to see your)')); ?>

                <?php echo e(Form::text('isID', null, array('class' => 'form-control'))); ?>

            </div></div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('picture', 'Picture')); ?>

                <?php echo e(Form::text('picture', null, array('class' => 'form-control'))); ?>

            </div></div></div>
            </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.schoolMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>