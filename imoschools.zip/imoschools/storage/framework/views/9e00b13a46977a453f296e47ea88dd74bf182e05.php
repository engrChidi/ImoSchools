<?php $__env->startSection('title'); ?>
    Display Schools
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <h2>Editing Schools</h2>
        <ol class="breadcrumb text-left">
            <li><a href="#">Home</a></li>
            <li><a href="#">Schools</a></li>
            <li class="active">Display</li>
        </ol>

    <div class="pull-right">
        <a class="btn btn-primary" href="<?php echo e(route('schools.index')); ?>"> Back</a>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                <?php echo e($schools->schoolname); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Details:</strong>
                <?php echo e($schools->address); ?>

            </div>
        </div>
    </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>logo:</strong>
                    <?php echo e($schools->logo); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Motto:</strong>
                    <?php echo e($schools->motto); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Comment:</strong>
                    <?php echo e($schools->comment); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>school Fees:</strong>
                    <?php echo e($schools->schoolfees); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Color:</strong>
                    <?php echo e($schools->color); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>phone:</strong>
                    <?php echo e($schools->phone); ?>

                </div>
            </div>
        </div>
        schoolname','address','logo','color','motto','phone','email','website','facilities','strongPoints','upcomingEvent','comment','admissionRequirements','schoolfees'

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>website:</strong>
                    <?php echo e($schools->website); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>facilities:</strong>
                    <?php echo e($schools->facilities); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Strong Points:</strong>
                    <?php echo e($schools->strongPoints); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>up Coming Events:</strong>
                    <?php echo e($schools->upcomingEvent); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>LGA:</strong>
                    <?php echo e($schools->admissionRequirements); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
               Thanks.
            </div>
        </div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.schoolMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>