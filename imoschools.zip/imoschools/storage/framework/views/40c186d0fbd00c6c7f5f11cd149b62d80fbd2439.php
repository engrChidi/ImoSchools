<?php $__env->startSection('title'); ?>
    Display Schools
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <h2>Editing Schools</h2>
        <ol class="breadcrumb text-left">
            <li><a href="#">Home</a></li>
            <li><a href="#">Schools</a></li>
            <li class="active">Display</li>
        </ol>
        <table class="table table-striped table-bordered table-responsive">
            <thead><tr> <td class="text-center">School Name</td> <td class="text-center">School Address</td><td class="text-center">Action</td></tr></thead>
            <tbody>
            <?php foreach($schools as $key=>$value): ?>
                <tr><td><?php echo e($value->schoolname); ?></td>
                    <td><?php echo e($value->address); ?></td>

                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.schoolMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>