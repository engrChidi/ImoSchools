<?php $__env->startSection('title'); ?>
School Registration
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">New School</li>
    </ol>
    <h1>Create a School</h1>

    <div class="alert alert-warning"> <!-- if there are creation errors, they will show here -->
        <?php echo e(Html::ul($errors->all())); ?>

    </div>
    <?php echo e(Form::open(array('route' => 'rate.store','method'=>'POST'))); ?>


    <div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('rater', 'The Rater')); ?>

                <?php echo e(Form::text('rater', null, array('class' => 'form-control'))); ?>

            </div>
        </div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('ratee', 'Ratee')); ?>

                <?php echo e(Form::text('ratee', null, array('class' => 'form-control'))); ?>

            </div> </div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('comment', 'Comment')); ?>

                <?php echo e(Form::text('comment', null, array('class' => 'form-control'))); ?>

            </div> </div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('raterid', 'Rater\'s ID:')); ?>

                <?php echo e(Form::text('raterid', null, array('placeholder' => 'Subject','class' => 'form-control','style'=>'color:blue'))); ?>

            </div></div></div><div class="row"><div class="col-md-6">
 <div class="form-group">
                <?php echo e(Form::label('rateeid', 'Ratee ID)')); ?>

                <?php echo e(Form::text('rateeid', null, array('placeholder' => 'The Current Class You Teach','class' => 'form-control','style'=>'color:blue'))); ?>

           </div>
    </div><div class="col-md-6">
 <div class="form-group">
                <?php echo e(Form::label('rate', 'The Rate)')); ?>

                <?php echo e(Form::text('rate', null, array('placeholder' => 'The Current Class You Teach','class' => 'form-control','style'=>'color:blue'))); ?>

            </div>
        </div>
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rateMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>