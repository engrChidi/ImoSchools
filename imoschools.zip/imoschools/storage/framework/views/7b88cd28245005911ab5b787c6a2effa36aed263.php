<?php $__env->startSection('title'); ?>
    Display Schools
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <h2>Editing Schools</h2>
        <ol class="breadcrumb text-left">
            <li><a href="#">Home</a></li>
            <li><a href="#">Schools</a></li>
            <li class="active">Teachers</li>
        </ol>

        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('business.index')); ?>"> Back</a>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Owner's Name:</strong>
                    <?php echo e($business->userName); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Business Name:</strong>
                    <?php echo e($business->businessName); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Comment:</strong>
                    <?php echo e($business->comment); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Products/Services:</strong>
                    <?php echo e($business->product); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Location:</strong>
                    <?php echo e($business->location); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Contact Phones:</strong>
                    <?php echo e($business->phone); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Product Image:</strong>
                    <?php echo e($business->image); ?>

                </div>
            </div>
            </div>

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Grade:</strong>
                    <?php echo e($business->grade); ?>

                </div>
            </div>

        </div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.businessMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>