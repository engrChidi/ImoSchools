<?php $__env->startSection('title'); ?>
School Registration
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">New School</li>
    </ol>
    <h1>Create a School</h1>

    <div class="alert alert-warning"> <!-- if there are creation errors, they will show here -->
    <?php echo e(Html::ul($errors->all())); ?>

    </div>
     <?php echo e(Form::open(array('route' => 'schools.store','method'=>'POST'))); ?>


<div class="row"><div class="col-md-6">
    <div class="form-group">
        <?php echo e(Form::label('schoolname', 'School Name')); ?>

        <?php echo e(Form::text('schoolname', null, array('class' => 'form-control'))); ?>

    </div>
    </div><div class="col-md-6">
    <div class="form-group">
        <?php echo e(Form::label('email', 'School Email')); ?>

        <?php echo e(Form::email('email', null, array('class' => 'form-control'))); ?>

    </div> </div></div><div class="row"><div class="col-md-6">
    <div class="form-group">
        <?php echo e(Form::label('phone', 'Contact Phone')); ?>

        <?php echo e(Form::text('phone', null, array('class' => 'form-control'))); ?>

    </div> </div><div class="col-md-6">
    <div class="form-group">
        <?php echo e(Form::label('strongPoints', 'Strong Points: (why should I choose your School?)')); ?>

        <?php echo e(Form::textarea('strongPoints', null, array('placeholder' => 'Details','class' => 'form-control','style'=>'color:blue'))); ?>

    </div></div></div><div class="row"><div class="col-md-6">
    <div class="form-group">
        <?php echo e(Form::label('facilities', 'Facilities: (School Bus, Hostel, Playground...)')); ?>

        <?php echo e(Form::textarea('facilities', null, array('placeholder' => 'Details','class' => 'form-control','style'=>'color:blue'))); ?>

    </div></div><div class="col-md-6">
    <div class="form-group">
        <?php echo e(Form::label('comment', 'COMMENT: (say something Good about your school)')); ?>

        <?php echo e(Form::textarea('comment', null, array('placeholder' => 'Details','class' => 'form-control','style'=>'color:blue'))); ?>

    </div></div></div><div class="row"><div class="col-md-6">
    <div class="form-group">
        <?php echo e(Form::label('color', 'school Uniform Color')); ?>

        <?php echo e(Form::text('color', null, array('class' => 'form-control'))); ?>

    </div></div><div class="col-md-6">
    <div class="form-group">
        <?php echo e(Form::label('website', 'Website (if you have)')); ?>

        <?php echo e(Form::text('website', null, array('class' => 'form-control'))); ?>

    </div></div></div><div class="row"><div class="col-md-6">
    <div class="form-group">
        <?php echo e(Form::label('schoolfees', 'School Fees per Term')); ?>

        <?php echo e(Form::text('schoolfees', null, array('class' => 'form-control'))); ?>

    </div></div><div class="col-md-6">
    <div class="form-group">
        <?php echo e(Form::label('upcomingEvent', 'Upcoming Event (Any Activity?')); ?>

        <?php echo e(Form::text('upcomingEvent', null, array('class' => 'form-control'))); ?>

    </div></div></div><div class="row"><div class="col-md-6">
    <div class="form-group">
        <?php echo e(Form::label('admissionRequirements', 'LGA')); ?>

        <?php echo e(Form::select('admissionRequirements', ['Aboh Mbaise', 'Ahiazu Mbaise', 'Ehime Mbano','Ezinihitte Mbaise', 'Ideato North', 'Ideato South',
        'Ihitte/Uboma','Ikeduru', 'Isiala Mbano', 'Isu','Mbaitoli','Ngor Okpala', 'Njaba', 'Nkwerre','Nwangele',
        'Obowo', 'Oguta', 'Ohaji/Egbema','Okigwe','Onuimo', 'Orlu', 'Orsu','Oru East', 'Oru West','Owerri Municipal', 'Owerri North','Owerri West'])); ?>

   </div> </div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('address', 'Address')); ?>

                <?php echo e(Form::text('address', null, array('class' => 'form-control'))); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::label('motto', 'Motto or Slogan')); ?>

                <?php echo e(Form::text('motto', null, array('class' => 'form-control'))); ?>

            </div></div>
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>