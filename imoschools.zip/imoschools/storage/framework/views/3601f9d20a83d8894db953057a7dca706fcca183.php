<?php
/**
 * Created by PhpStorm.
 * User: hp
 * Date: 4/25/2017
 * Time: 9:35 AM
 */
echo "School Home";