<?php $__env->startSection('title'); ?>
Teacher Registration
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>;
    <div class="pull-left">
        <h2>Teacher List</h2>
    </div>
    <div class="pull-right">
        <a class="btn btn-success" href="<?php echo e(route('students.create')); ?>"> Create New Students</a>
    </div>
 <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Students Name</th>
            <th>Phone </th>
            <th>Subjects</th>
            <th width="280px">Action</th>
        </tr>
        <?php foreach($students as $student): ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($student->studentName); ?></td>
                <td><?php echo e($student->phone); ?></td>
                <td><?php echo e($student->gender); ?></td>
                <td> <a href='<?php echo e(asset("img/$student->img")); ?>'><?php echo e($student->img); ?></a></td>
                <td>
                    <a class="btn btn-info" href="<?php echo e(route('students.show',$student->id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('students.edit',$student->id)); ?>">Edit</a>
                    <?php echo e(Form::open(['method' => 'DELETE','route' => ['students.destroy', $student->id],'style'=>'display:inline'])); ?>

                    <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                    <?php echo e(Form::close()); ?>

                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <?php echo e($students->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.studentsMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>