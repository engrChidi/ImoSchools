<?php $__env->startSection('title'); ?>
    Display Schools
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <h2>Editing Schools</h2>
        <ol class="breadcrumb text-left">
            <li><a href="#">Home</a></li>
            <li><a href="#">Schools</a></li>
            <li class="active">Teachers</li>
        </ol>

        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('teachers.index')); ?>"> Back</a>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Name:</strong>
                    <?php echo e($teachers->teacherName); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Details:</strong>
                    <?php echo e($teachers->phone); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Comment:</strong>
                    <?php echo e($teachers->comment); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Subjects:</strong>
                    <?php echo e($teachers->subjects); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Class:</strong>
                    <?php echo e($teachers->currentclass); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>school Fees:</strong>
                    <?php echo e($teachers->isID); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Gender:</strong>
                    <?php echo e($teachers->gender); ?>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>\picture:</strong>
                    <?php echo e($teachers->picture); ?>

                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Grade:</strong>
                    <?php echo e($teachers->grade); ?>

                </div>
            </div>

        </div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacherMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>