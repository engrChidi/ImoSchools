<?php $__env->startSection('title'); ?>
Edit Busiess
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">Display</li>
    </ol>
    <div class="row">

        <div class="col-lg-12 margin-tb">

            <div class="pull-left">

                <h2>Edit Business</h2>

            </div>

            <div class="pull-right">

                <a class="btn btn-primary" href="<?php echo e(URL::to('business.show')); ?>"> Back</a>
            </div>
        </div>

    </div>
    <?php if(count($errors) > 0): ?>

        <div class="alert alert-danger">

            <strong>Whoops!</strong> There were some problems with your input.<br><br>

            <ul> <?php foreach($errors->all() as $error): ?>

                    <li><?php echo e($error); ?></li>

                <?php endforeach; ?>

            </ul>

        </div>

    <?php endif; ?>
    <?php echo e(Form::model($business, ['method' => 'PATCH','route' => ['business.update', $business->id]])); ?>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Business Owner's Name:</strong>
                <?php echo e(Form::text('userName', null, array('placeholder' => 'Title','class' => 'form-control'))); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Business Name:</strong>
                <?php echo e(Form::textarea('businessName', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px'))); ?>

            </div></div></div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Phone:</strong>
                <?php echo e(Form::text('phone', null, array('placeholder' => 'Title','class' => 'form-control'))); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Product Image:</strong>
                <?php echo e(Form::textarea('image', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px'))); ?>

            </div></div></div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Business Address:</strong>
                <?php echo e(Form::text('location', null, array('placeholder' => 'Title','class' => 'form-control'))); ?>

            </div>
        </div><div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Product/Services:</strong>
                <?php echo e(Form::text('product', null, array('placeholder' => 'Title','class' => 'form-control'))); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Comment:</strong>
                <?php echo e(Form::textarea('comment', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px'))); ?>

            </div></div></div>
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.schoolMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>