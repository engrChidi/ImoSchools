<?php $__env->startSection('title'); ?>
School Registration
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">New School</li>
    </ol>
    <h1>Create a School</h1>

    <div class="alert alert-warning"> <!-- if there are creation errors, they will show here -->
        <?php echo e(Html::ul($errors->all())); ?>

    </div>
    <?php echo e(Form::open(array('route' => 'students.store','method'=>'POST','files'=>true))); ?>


    <div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('studentName', 'Teacher Name')); ?>

                <?php echo e(Form::text('studentName', null, array('class' => 'form-control'))); ?>

            </div>
        </div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('phone', 'Phone Number')); ?>

                <?php echo e(Form::text('phone', null, array('class' => 'form-control'))); ?>

            </div> </div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('level', 'Level')); ?>

                <?php echo e(Form::text('level', null, array('class' => 'form-control'))); ?>

            </div> </div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('dob', 'DateOfBirth (just Month & Day')); ?>

                <?php echo e(Form::text('dob', null, array('placeholder' => 'e.g 24/07','class' => 'form-control','style'=>'color:blue'))); ?>

            </div></div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('gender', 'Gender:')); ?>

                <?php echo e(Form::select('gender', ['Male','Female'], null, array('class'=>'form-control'))); ?>

            </div></div><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('isID', 'Your SchoolID: (get it Here)')); ?>

                <?php echo e(Form::text('isID', null, array('placeholder' => 'Your School ID','class' => 'form-control','style'=>'color:blue'))); ?>

            </div></div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                <?php echo e(Form::label('img', 'Picture')); ?>

                <?php echo e(Form::file('img', array('class' => 'form-control'))); ?>

            </div></div><div class="col-md-6">efef</div></div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.schoolMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>