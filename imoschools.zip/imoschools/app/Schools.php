<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Schools extends Model
{
    public $fillable = ['schoolname','address','logo','color','motto','phone','email','website','facilities','strongPoints','upcomingEvent','comment','lga','schoolfees'];
}