<?php

namespace App\Http\Controllers;

use App\Students;
use Illuminate\Http\Request;

use App\Http\Requests;

class StudentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $students = Students::orderby('id', 'DESC')->paginate(5);
        return view('students.index', compact('students'))
            ->with('i', ($request->input('page', 1) -1) *5); //  //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */public function create()
    {
        return view('students.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'studentName' => 'required',
            'phone'=>'required',
            'gender'=>'required',
            'level'=>'required',
            'dob'=>'required',
            'rate'=>'string',
            'img' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
             ]);
      $students =  new Students(array(
          'studentName' => $request->get('studentName'),
          'phone'=>$request->get('phone'),
          'gender'=>$request->get('gender'),
          'level'=>$request->get('level'),
          'dob'=>$request->get('dob')
                  ));

        if($file = $request->hasFile('img')) {

            $imageName =$students->phone."~". $request->file('img')->getClientOriginalName();
             $request->file('img')->move(
                 public_path() . '\img/', $imageName);
            $students->img = $imageName ;
        }
        $students->save() ;
    return redirect()->route('students.index')
        ->with('message', 'New Student Saved!');

    }
    /*
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $students=Students::find($id);
        return view('students.show',compact('students'));
    }

    /**
     * Show the form for editing the specified resource.
     *S
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $students=Students::find($id);
        return view('students.edit',compact('students'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'studentName' => 'required',
            'phone'=>'required|numeric|unique:students',
            'gender'=>'required',
            'level'=>'required',
            'dob'=>'required',
            'rate'=>'string',
            'img' => 'string' ]);
        Students::find($id)->update($request->all());
        return redirect()->route('students.index')
            ->with('success', 'Student Info Updated Properly');
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Students::find($id)->delete();
        return redirect()->route('students.index')
            ->with('success', 'Deletion Executed Correctly');
    }
}
