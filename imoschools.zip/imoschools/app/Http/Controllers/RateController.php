<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Rate;

class RateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $rate= Rate::orderBy('id','DESC')->paginate(5);
        return view('rate.index',compact('rate'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('rate.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'rater'=>'required',
            'ratee'=>'required',
            'comment'=>'string',
            'rate'=>'required',
                   ]);
        Rate::create($request->all());
        return redirect()->route('rate.index')
            ->with('success', 'New Rate Submitted successfully');
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $rate = Rate::find($id);
        return view('rate.show', compact('rate'));   //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $rate = Rate::find($id);
        return view('rate.edit', compact('rate'));//
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'rater'=>'required',
            'ratee'=>'required',
            'comment'=>'string',
            'rate'=>'required',
        ]);
        Rate::find($id)->update($request->all());
        return redirect()->route('rate.index')
            ->with('success', 'Rating Updated'); //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Rate::find($id)->delete();
        return redirect()->route('rate.index')
            ->with('success', 'Rating Deleted Properly');  //
    }
}
