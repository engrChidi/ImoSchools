<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use DB;
use App\Http\Controllers\Controller;
use User;

class LoginController extends Controller
{
    public function index(Request $request)
    {
// validate the info, create rules for the inputs
       $this->validate($request,[
            'role' => 'required',
            'password' => 'required|alphaNum|min:3',
            'phone' => 'numeric|required']);
            $role = $request->input('role');
            $phone = $request->input('phone');
            $password = DB::table('users')->where('phone', $phone)->value('password');
            $passw = bcrypt($request->input('password'));

        if ($password === $passw) {
//test roles
                if ($role === 'Teacher') {
                    echo "Teacher";
                } else if ($role === 'School') {
                  //  return redirect('/schools.home');
                    echo "School";
                } else if ($role === 'Student') {
                    return redirect('/students.home');
                } else if ($role === 'Advert') {
                    return redirect('/business.home');
                } else
                    return redirect()->route('/login');
            } else {
                return redirect('/')
                    ->with('error', 'Wrong Password or other Login Credentials');
            }
        }

        public function doLogout()
    {
        Auth::logout(); // log the user out of our application
        return Redirect::to('login'); // redirect the user to the login screen
    }
    public function showLogin()
    {
        // show the form
        return View('/auth.login');
    }

}