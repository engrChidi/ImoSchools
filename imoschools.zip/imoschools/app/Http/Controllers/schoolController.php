<?php

namespace App\Http\Controllers;

use App\Schools;
use Illuminate\Http\Request;

use App\Http\Requests;

class schoolController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
       return view('schools.home');
        /*$schools= Schools::orderBy('id','DESC')->paginate(5);
             return view('schools.index',compact('schools'))
          ->with('i', ($request->input('page', 1) - 1) * 5);
        */
    }

    public function create()
    {
        return view('schools.Create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'schoolname' => 'required|unique:schools',
            'address' => 'required',
            'phone' => 'required|numeric',
            'strongPoints' => 'required',
            'admissionRequirements' => 'required',
            'facilities' => 'required',
            'schoolfees' => 'required',
            'logo' => 'string',
            'color' => 'string',
            'motto' => 'string',
            'email' => 'email',
            'website' => 'string',
            'upcomingEvent'=>'string',
            'comment'=>'string',
        ]);
        //Company is from Model where we have *** extends Model
        Schools::create($request->all());
       return redirect()->route('schools.index')
            ->with('success', 'New School Registered Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $schools = Schools::find($id);
        return view('schools.show', compact('schools'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $schools = Schools::find($id);
        return view('schools.Edit', compact('schools'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'schoolname' => 'required|unique:schools',
            'address' => 'required',
            'phone' => 'required|numeric',
            'strongPoints' => 'required',
            'admissionRequirements' => 'required',
            'facilities' => 'required',
            'schoolfees' => 'required',
            'logo' => 'string',
            'color' => 'string',
            'motto' => 'string',
            'email' => 'email',
            'website' => 'string',
            'upcomingEvent'=>'string',
            'comment'=>'string',
        ]);
        Schools::find($id)->update($request->all());
        return redirect()->route('schools.index')
            ->with('success', 'School Data Updated Successfully');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Schools::find($id)->delete();
        return redirect()->route('schools.index')
            ->width('success', 'School Deleted Properly');

    }
}
