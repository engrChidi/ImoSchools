<?php

namespace App\Http\Controllers\Auth;

use App\User;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use Auth;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use ThrottlesLogins;
use AuthenticatesAndRegistersUsers;
    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */

    protected function authenticated($request, $user)

    {
        if($user->role === 'teacher') {
            return redirect()->intended('/teachers.home');
        }else if($user->role === 'school'){
            return redirect()->intended('/schools.home');
    }else if($user->role === 'student'){
            return redirect()->intended('/students.home');
        }else if($user->role === 'business'){
            return redirect()->intended('/business.home');
        }else
        return redirect()->intended('/welcome');
    }
   // protected $redirectTo = '/';

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware($this->guestMiddleware(), ['except' => 'logout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'phone' => 'required|max:13',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|min:6|confirmed',
            'role' => 'required'
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        return User::create([
            'phone' => $data['email'],
            'email' => $data['phone'],
            'password' => bcrypt($data['password']),
            'role'=>$data['role']
        ]);
    }
}
