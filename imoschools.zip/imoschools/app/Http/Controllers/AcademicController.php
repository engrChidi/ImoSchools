<?php

namespace App\Http\Controllers;

use App\Academics;
use Illuminate\Http\Request;

use App\Http\Requests;

class AcademicController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $academics = Academics::orderby('id', 'DESC')->paginate(5);
        return view('academics.index', compact('academics'))
            ->with('i', ($request->input('page', 1) -1) *5); //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('academics.create');//
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'userName' => 'required|unique:academics',
            'qualification'=>'required',
            'lga'=>'required',
            'phone'=>'required',
            'subject'=>'required',
            'comment'=>'string',
            'uploadQuestion' => 'string' ]);
        Academics::create($request->all());
        return redirect()->route('academics.index')
            ->with('success','New Academician Added Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       $academics=Academics::find($id);
        return view('academics.show',compact('academics'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $academics = Academics::find($id);
        return view('academics.edit', compact('academics'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'userName' => 'required|unique:academics',
            'qualification'=>'required',
            'lga'=>'required',
            'phone'=>'required',
            'subject'=>'required',
            'comment'=>'string',
            'uploadQuestion' => 'string' ]);
        Academics::find($id)->update($request->all());
        return redirect()->route('academics.index')
            ->with('success', 'Academic Info Updated Properly');
    }
/**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Academics::find($id)->delete();
        return redirect()->route('academics.index')
        ->with('success', 'Deletion Executed Correctly');
        //
    }
}
