<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Teachers;

class TeacherController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
      $teachers = Teachers::orderby('id', 'DESC')->paginate(5);
        return view('teachers.index', compact('teachers'))
        ->with('i', ($request->input('page', 1) -1) * 5);
 }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      return view('teachers.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
       'teacherName'=>'required',
            'phone'=>'required|numeric|unique:teachers',
            'gender'=>'required|string',
            'subjects'=>'required|string',
            'currentclass'=>'string',
            'comment'=>'string',
            'isID'=>'required',
           // 'picture'=>'image',
            'grade'=>'string'
    ]);
        Teachers::create($request->all());
        return redirect()->route('teachers.index')
            ->with('success', 'New Teachers Registered successfully');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       $teachers = Teachers::find($id);
        return view('teachers.show', compact('teachers'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $teachers = Teachers::find($id);
        return view('teachers.edit', compact('teachers'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'teacherName'=>'required',
            'phone'=>'required|numeric|unique:teachers',
            'gender'=>'required|string',
            'subjects'=>'required|string',
            'currentclass'=>'string',
            'comment'=>'string',
            'isID'=>'required',
            //'picture'=>'image',
            'grade'=>'string'
        ]);
        Teachers::find($id)->update($request->all());
        return redirect()->route('teachers.index')
            ->with('success', 'Teacher Details Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       Teachers::find($id)->delete();
        return redirect()->route('teachers.index')
            ->with('success', 'Teacher Deleted Properly');

    }
}
