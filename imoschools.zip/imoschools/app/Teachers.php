<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teachers extends Model
{
    public $fillable = ['teacherName','phone','gender','subjects','currentclass','comment','isID','picture','grade'];
}
