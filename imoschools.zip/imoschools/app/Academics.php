<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Academics extends Model
{
   public $fillable=['userName','qualification','lga','subject','uploadQuestion','phone','comment'
   ]; //

}
