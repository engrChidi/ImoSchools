<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Business extends Model
{
    public $fillable=['userName','businessName','location','phone','product','comment','image'];
}
