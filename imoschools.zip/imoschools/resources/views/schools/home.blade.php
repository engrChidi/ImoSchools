@extends('layouts.schoolMaster')
@Section('title')
School
@endsection
@section('content')
    <div class="panel">
        <h2>welcome #SchoolName</h2>
        <h3>You can upgrade to paid service</h3>
       <b>ADVANTAGES:</b><ul>
            <li>Appear in the top list when people search/filter Good schools</li>
            <li>Feature in our Homepage for visibility</li>
            <li>Placeyour Admission Form for catching Potential Students here</li>
                    </ul>
        <h4>You can also <a href=""> invite a co school owner </a> to join the platform, or help to Register those who cannot. Its a true act of friendship. </h4></div>
    <div class="row">
        <div class="col-md-6">
            Adverts of people that are school targetted.
        </div>
        <div class="col-md-6">
            Other things can be here too, this side.
        </div>
    </div>
@endsection