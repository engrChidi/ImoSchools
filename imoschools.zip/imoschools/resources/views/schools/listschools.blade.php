@extends('layouts.schoolMaster')
@section('title')
    Display Schools
@endsection
@section('content')

    <div class="jumbotron">
       <h2>Editing Schools</h2>
            <ol class="breadcrumb text-left">
                <li><a href="#">Home</a></li>
                <li><a href="#">Schools</a></li>
                <li class="active">Display</li>
            </ol>
        <table class="table table-striped table-bordered table-responsive">
            <thead><tr> <td class="text-center">School Name</td> <td class="text-center">School Address</td><td class="text-center">Action</td></tr></thead>
            <tbody>
            @foreach($schools as $key=>$value)
               <tr><td>{{ $value->schoolname}}</td>
                   <td>{{ $value->address}}</td>

               </tr>
                @endforeach
            </tbody>
        </table>
        </div>
@endsection

