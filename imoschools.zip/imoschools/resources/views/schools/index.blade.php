@extends('layouts.schoolMaster')
@Section('title')
School Registration
@endsection
@section('content')

        @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
        @endif

            <div class="pull-left">
                <h2>School List</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('schools.create') }}"> Create New Product</a>
            </div>



    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Details</th>
            <th>Motto</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($schools as $school)
            <tr>
                <td>{{ ++$i }}</td>
                <td>{{ $school->schoolname}}</td>
                <td>{{ $school->address}}</td>
                <td>{{ $school->motto}}</td>
                <td>
                    <a class="btn btn-info" href="{{ route('schools.show',$school->id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('schools.edit',$school->id) }}">Edit</a>
                    {{ Form::open(['method' => 'DELETE','route' => ['schools.destroy', $school->id],'style'=>'display:inline']) }}
                    {{ Form::submit('Delete', ['class' => 'btn btn-danger']) }}

                    {{ Form::close() }}
                </td>
            </tr>
        @endforeach
    </table>

    {{ $schools->render() }}
    @endsection