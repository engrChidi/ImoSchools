@extends('layouts.schoolMaster')
@Section('title')
School Registration
@endsection
@section('content')
        <ol class="breadcrumb">
                <li><a href="#">Home</a></li>
                <li><a href="#">Schools</a></li>
                <li class="active">Display</li>
        </ol>
        <div class="row">

                <div class="col-lg-12 margin-tb">

                        <div class="pull-left">

                                <h2>Edit School</h2>

                        </div>

                        <div class="pull-right">

                                <a class="btn btn-primary" href="{{ URL::to('schools.show') }}"> Back</a>
</div>
   </div>

        </div>
  @if (count($errors) > 0)

                <div class="alert alert-danger">

                        <strong>Whoops!</strong> There were some problems with your input.<br><br>

                        <ul> @foreach ($errors->all() as $error)

                                        <li>{{ $error }}</li>

                                @endforeach

                        </ul>

                </div>

        @endif
{{Form::model($schools, ['method' => 'PATCH','route' => ['schools.update', $schools->id]])}}
   <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-6">
 <div class="form-group"><strong>School Name:</strong>
{{ Form::text('schoolname', null, array('placeholder' => 'Title','class' => 'form-control')) }}
 </div>
  </div>
 <div class="col-xs-12 col-sm-12 col-md-6">
 <div class="form-group"><strong>Motto:</strong>
{{ Form::textarea('motto', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px')) }}
</div></div></div>
           <div class="row">
                   <div class="col-xs-12 col-sm-12 col-md-6">
                           <div class="form-group"><strong>Address:</strong>
                                   {{ Form::text('address', null, array('placeholder' => 'Title','class' => 'form-control')) }}
                           </div>
                   </div>
                   <div class="col-xs-12 col-sm-12 col-md-6">
                           <div class="form-group"><strong>Logo:</strong>
                                   {{ Form::textarea('logo', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px')) }}
                           </div></div></div>
                           <div class="row">
                                   <div class="col-xs-12 col-sm-12 col-md-6">
                                           <div class="form-group"><strong>Color:</strong>
                                                   {{ Form::text('color', null, array('placeholder' => 'Title','class' => 'form-control')) }}
                                           </div>
                                   </div>
                                    <div class="col-xs-12 col-sm-12 col-md-6">
                                           <div class="form-group"><strong>Contact Phone:</strong>
                                                   {{ Form::textarea('phone', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px')) }}
                                           </div></div></div>
                                   <div class="row">
                                           <div class="col-xs-12 col-sm-12 col-md-6">
                                                   <div class="form-group"><strong>E-Mail:</strong>
                                                           {{ Form::text('email', null, array('placeholder' => 'Title','class' => 'form-control')) }}
                                                   </div>
                                           </div>
                                           <div class="col-xs-12 col-sm-12 col-md-6">
                                                   <div class="form-group"><strong>Website:</strong>
                                                           {{ Form::textarea('website', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px')) }}
                                                   </div></div></div>
                                           <div class="row">
                                                   <div class="col-xs-12 col-sm-12 col-md-6">
                                                           <div class="form-group"><strong>Facilities:</strong>
                                                                   {{ Form::text('facilities', null, array('placeholder' => 'Title','class' => 'form-control')) }}
                                                           </div>
                                                   </div>
                                                   <div class="col-xs-12 col-sm-12 col-md-6">
                                                           <div class="form-group"><strong>Strong Point:</strong>
                                                                   {{ Form::textarea('strongPoints', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px')) }}
                                                           </div></div></div>
                                                  <div class="row">
                                                           <div class="col-xs-12 col-sm-12 col-md-6">
                                                                   <div class="form-group"><strong>Up Coming Events:</strong>
                                                                           {{ Form::text('upcomingEvent', null, array('placeholder' => 'Title','class' => 'form-control')) }}
                                                                   </div>
                                                           </div>
                                                           <div class="col-xs-12 col-sm-12 col-md-6">
                                                                   <div class="form-group"><strong>Comment:</strong>
                                                                           {{ Form::textarea('comment', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px')) }}
                                                                   </div></div></div>
                                                           <div class="row">
                                                                   <div class="col-xs-12 col-sm-12 col-md-6">
                                                                           <div class="form-group"><strong>LGA:</strong>
                                                                                   {{ Form::text('admissionRequirements', null, array('placeholder' => 'Title','class' => 'form-control')) }}
                                                                           </div>
                                                                   </div>
                                                                   <div class="col-xs-12 col-sm-12 col-md-6">
                                                                           <div class="form-group"><strong>Schoo Fee:</strong>
                                                                                   {{ Form::textarea('schoolfees', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px')) }}
                                                                           </div></div></div>
                                                   <div class="col-xs-12 col-sm-12 col-md-12 text-center">
  <button type="submit" class="btn btn-primary">Submit</button>
</div>
 </div>
{!! Form::close() !!}

@endsection
