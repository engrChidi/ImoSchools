@extends('layouts.schoolMaster')
@section('title')
    Display Schools
@endsection
@section('content')

    <div class="jumbotron">
        <h2>Editing Schools</h2>
        <ol class="breadcrumb text-left">
            <li><a href="#">Home</a></li>
            <li><a href="#">Schools</a></li>
            <li class="active">Display</li>
        </ol>

    <div class="pull-right">
        <a class="btn btn-primary" href="{{ route('schools.index') }}"> Back</a>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong>
                {{ $schools->schoolname}}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Details:</strong>
                {{ $schools->address}}
            </div>
        </div>
    </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>logo:</strong>
                    {{ $schools->logo}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Motto:</strong>
                    {{ $schools->motto}}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Comment:</strong>
                    {{ $schools->comment}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>school Fees:</strong>
                    {{ $schools->schoolfees}}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Color:</strong>
                    {{ $schools->color}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>phone:</strong>
                    {{ $schools->phone}}
                </div>
            </div>
        </div>
        schoolname','address','logo','color','motto','phone','email','website','facilities','strongPoints','upcomingEvent','comment','admissionRequirements','schoolfees'

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>website:</strong>
                    {{ $schools->website}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>facilities:</strong>
                    {{ $schools->facilities}}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Strong Points:</strong>
                    {{ $schools->strongPoints}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>up Coming Events:</strong>
                    {{ $schools->upcomingEvent}}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>LGA:</strong>
                    {{ $schools->admissionRequirements}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
               Thanks.
            </div>
        </div></div>
@endsection