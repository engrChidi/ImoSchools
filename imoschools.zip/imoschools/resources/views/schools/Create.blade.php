@extends('layouts.app')
@Section('title')
School Registration
@endsection
@section('content')
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">New School</li>
    </ol>
    <h1>Create a School</h1>

    <div class="alert alert-warning"> <!-- if there are creation errors, they will show here -->
    {{ Html::ul($errors->all()) }}
    </div>
     {{ Form::open(array('route' => 'schools.store','method'=>'POST')) }}

<div class="row"><div class="col-md-6">
    <div class="form-group">
        {{ Form::label('schoolname', 'School Name') }}
        {{ Form::text('schoolname', null, array('class' => 'form-control')) }}
    </div>
    </div><div class="col-md-6">
    <div class="form-group">
        {{ Form::label('email', 'School Email') }}
        {{ Form::email('email', null, array('class' => 'form-control')) }}
    </div> </div></div><div class="row"><div class="col-md-6">
    <div class="form-group">
        {{ Form::label('phone', 'Contact Phone') }}
        {{ Form::text('phone', null, array('class' => 'form-control')) }}
    </div> </div><div class="col-md-6">
    <div class="form-group">
        {{ Form::label('strongPoints', 'Strong Points: (why should I choose your School?)') }}
        {{ Form::textarea('strongPoints', null, array('placeholder' => 'Details','class' => 'form-control','style'=>'color:blue')) }}
    </div></div></div><div class="row"><div class="col-md-6">
    <div class="form-group">
        {{ Form::label('facilities', 'Facilities: (School Bus, Hostel, Playground...)') }}
        {{ Form::textarea('facilities', null, array('placeholder' => 'Details','class' => 'form-control','style'=>'color:blue')) }}
    </div></div><div class="col-md-6">
    <div class="form-group">
        {{ Form::label('comment', 'COMMENT: (say something Good about your school)') }}
        {{ Form::textarea('comment', null, array('placeholder' => 'Details','class' => 'form-control','style'=>'color:blue')) }}
    </div></div></div><div class="row"><div class="col-md-6">
    <div class="form-group">
        {{ Form::label('color', 'school Uniform Color') }}
        {{ Form::text('color', null, array('class' => 'form-control')) }}
    </div></div><div class="col-md-6">
    <div class="form-group">
        {{ Form::label('website', 'Website (if you have)') }}
        {{ Form::text('website', null, array('class' => 'form-control')) }}
    </div></div></div><div class="row"><div class="col-md-6">
    <div class="form-group">
        {{ Form::label('schoolfees', 'School Fees per Term') }}
        {{ Form::text('schoolfees', null, array('class' => 'form-control')) }}
    </div></div><div class="col-md-6">
    <div class="form-group">
        {{ Form::label('upcomingEvent', 'Upcoming Event (Any Activity?') }}
        {{ Form::text('upcomingEvent', null, array('class' => 'form-control')) }}
    </div></div></div><div class="row"><div class="col-md-6">
    <div class="form-group">
        {{ Form::label('admissionRequirements', 'LGA') }}
        {{ Form::select('admissionRequirements', ['Aboh Mbaise', 'Ahiazu Mbaise', 'Ehime Mbano','Ezinihitte Mbaise', 'Ideato North', 'Ideato South',
        'Ihitte/Uboma','Ikeduru', 'Isiala Mbano', 'Isu','Mbaitoli','Ngor Okpala', 'Njaba', 'Nkwerre','Nwangele',
        'Obowo', 'Oguta', 'Ohaji/Egbema','Okigwe','Onuimo', 'Orlu', 'Orsu','Oru East', 'Oru West','Owerri Municipal', 'Owerri North','Owerri West'])}}
   </div> </div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('address', 'Address') }}
                {{ Form::text('address', null, array('class' => 'form-control')) }}
            </div>

            <div class="form-group">
                {{ Form::label('motto', 'Motto or Slogan') }}
                {{ Form::text('motto', null, array('class' => 'form-control')) }}
            </div></div>
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

    </div>
@endsection