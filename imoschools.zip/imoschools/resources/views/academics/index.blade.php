@extends('layouts.academicMaster')
@Section('title')
Teacher Registration
@endsection
@section('content')

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <div class="pull-left">
        <h2>Academicians List</h2>
    </div>
    <div class="pull-right">
        <a class="btn btn-success" href="{{ route('academics.create') }}"> Create New Product</a>
    </div>



    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>TeacherName</th>
            <th>Phone</th>
            <th>Subjects</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($academics as $academic)
            <tr>
                <td>{{ ++$i }}</td>
                <td>{{ $academic->userName}}</td>
                <td>{{ $academic->phone}}</td>
                <td>{{ $academic->subject}}</td>
                <td>
                    <a class="btn btn-info" href="{{ route('academics.show',$academic->id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('academics.edit',$academic->id) }}">Edit</a>
                    {{ Form::open(['method' => 'DELETE','route' => ['academics.destroy', $academic->id],'style'=>'display:inline']) }}
                    {{ Form::submit('Delete', ['class' => 'btn btn-danger']) }}

                    {{ Form::close() }}
                </td>
            </tr>
        @endforeach
    </table>

    {{ $academics->render() }}
@endsection