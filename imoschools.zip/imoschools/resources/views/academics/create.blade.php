@extends('layouts.app')
@Section('title')
School Registration
@endsection
@section('content')
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">New School</li>
    </ol>
    <h1>Create a School</h1>

    <div class="alert alert-warning"> <!-- if there are creation errors, they will show here -->
        {{ Html::url($errors->all()) }}
    </div>
    {{ Form::open(array('route' => 'academics.store','method'=>'POST')) }}

    <div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('userName', 'User Name') }}
                {{ Form::text('userName', null, array('class' => 'form-control')) }}
            </div>
        </div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('phone', 'Phone Number') }}
                {{ Form::text('phone', null, array('class' => 'form-control')) }}
            </div> </div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('comment', 'Comment') }}
                {{ Form::text('comment', null, array('class' => 'form-control')) }}
            </div> </div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('subject', 'Subjects:') }}
                {{ Form::text('subject', null, array('placeholder' => 'Subject','class' => 'form-control','style'=>'color:blue')) }}
            </div></div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('lga', 'Your LGA:') }}
                {{ Form::select('lga', ['Aboh Mbaise', 'Ahiazu Mbaise', 'Ehime Mbano','Ezinihitte Mbaise', 'Ideato North', 'Ideato South',
              'Ihitte/Uboma','Ikeduru', 'Isiala Mbano', 'Isu','Mbaitoli','Ngor Okpala', 'Njaba', 'Nkwerre','Nwangele',
              'Obowo', 'Oguta', 'Ohaji/Egbema','Okigwe','Onuimo', 'Orlu', 'Orsu','Oru East', 'Oru West','Owerri Municipal', 'Owerri North','Owerri West'],
              null,array('class'=>'form-control'))}}
            </div></div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('uploadQuestion', 'Upload Question (Must be in Ms Word)') }}
                {{ Form::text('uploadQuestion', null, array('placeholder' => 'The Current Class You Teach','class' => 'form-control','style'=>'color:blue')) }}
            </div><div class="form-group">
                {{ Form::label('qualification', 'Qualification') }}
                {{ Form::text('qualification', null, array('placeholder' => 'The Current Class You Teach','class' => 'form-control','style'=>'color:blue')) }}
            </div></div></div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

    </div>
@endsection

'userName','qualification','lga','subject','uploadQuestion','phone','comment'