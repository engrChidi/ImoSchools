@extends('layouts.app')
@section('title')
    Display Schools
@endsection
@section('content')

    <div class="jumbotron">
        <h2>Editing Schools</h2>
        <ol class="breadcrumb text-left">
            <li><a href="#">Home</a></li>
            <li><a href="#">Schools</a></li>
            <li class="active">Teachers</li>
        </ol>

        <div class="pull-right">
            <a class="btn btn-primary" href="{{ route('academics.index') }}"> Back</a>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Name:</strong>
                    {{ $academics->userName}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Details:</strong>
                    {{ $academics->phone}}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Comment:</strong>
                    {{ $academics->comment}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Subject:</strong>
                    {{ $academics->subject}}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Qualification:</strong>
                    {{ $academics->qualification}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>LGA:</strong>
                    {{ $academics->lga}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Upload Paper:</strong>
                    {{ $academics->uploadQuestion}}
                </div>
            </div>
        </div>
            </div>
@endsection