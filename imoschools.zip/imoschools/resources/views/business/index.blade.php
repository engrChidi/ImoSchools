@extends('layouts.businessMaster')
@Section('title')
Teacher Registration
@endsection
@section('content')

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <div class="pull-left">
        <h2>Business List</h2>
    </div>
    <div class="pull-right">
        <a class="btn btn-success" href="{{ route('business.create') }}"> Create New Business</a>
    </div>



    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>TeacherName</th>
            <th>Phone</th>
            <th>Subjects</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($business as $busi)
            <tr>
                <td>{{ ++$i }}</td>
                <td>{{ $busi->userName}}</td>
                <td>{{ $busi->phone}}</td>
                <td>{{ $busi->businessName}}</td>
                <td>
                    <a class="btn btn-info" href="{{ route('business.show',$busi->id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('business.edit',$busi->id) }}">Edit</a>
                    {{ Form::open(['method' => 'DELETE','route' => ['business.destroy', $busi->id],'style'=>'display:inline']) }}
                    {{ Form::submit('Delete', ['class' => 'btn btn-danger']) }}

                    {{ Form::close() }}
                </td>
            </tr>
        @endforeach
    </table>

    {{ $business->render() }}
@endsection