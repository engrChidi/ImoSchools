@extends('layouts.app')
@Section('title')
School Registration
@endsection
@section('content')
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">New School</li>
    </ol>
    <h1>Create a School</h1>

    <div class="alert alert-warning"> <!-- if there are creation errors, they will show here -->
        {{ Html::ul($errors->all()) }}
    </div>
    {{ Form::open(array('route' => 'business.store','method'=>'POST')) }}

    <div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('userName', 'Name of Business Owner') }}
                {{ Form::text('userName', null, array('class' => 'form-control')) }}
            </div>
        </div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('businessName', 'Business Name') }}
                {{ Form::text('businessName', null, array('class' => 'form-control')) }}
            </div> </div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('product', 'Product/Services Offered') }}
                {{ Form::text('product', null, array('class' => 'form-control')) }}
            </div> </div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('location', 'Office Address') }}
                {{ Form::textarea('location', null, array('placeholder' => 'Subjects You Teach','class' => 'form-control','style'=>'color:blue')) }}
            </div></div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('image', 'Product Picture:') }}
                {{ Form::text('image', null, array('class'=>'form-control'))}}
            </div></div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('comment', 'Comment: (say something good about your Business)') }}
                {{ Form::text('comment', null, array('placeholder' => 'The Current Class You Teach','class' => 'form-control','style'=>'color:blue')) }}
            </div></div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('phone', 'Contact Phone: (separate with comma if more than one)') }}
                {{ Form::text('phone', null, array('class' => 'form-control')) }}
            </div></div>
        <div class="col-md-6">

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </div>
    </div>
@endsection