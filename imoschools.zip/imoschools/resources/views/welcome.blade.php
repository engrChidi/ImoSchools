@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"><i class="glyphicon glyphicon-education" style="font-size: 1.2em"> </i> Education News: <span><marquee behavior="scroll" >All the Hot News on Education will be flashing in and going. choose any format.</marquee></span></div>

                <div class="panel-body">
              <img src="/src/img/images.png" class="img img-thumbnail img-responsive" alt="goodschools.info">
                   <a href="{{ url('/register') }}" title="Access free Education Materials,Compete in Best Students Award, etc"> <i class="fa fa-angle-double-right"> </i> Register as a Student</a> &nbsp;&nbsp;  <span>
                  <a href="" title="Compete in Best Teacher Award, etc"> <i class="fa fa-angle-double-right"> </i> Register as a Teacher</a></span> &nbsp;&nbsp;
                    <span><a href="" title="increase your Customers and Sales, etc"> <i class="fa fa-angle-double-right"> </i> Advertise Your Business</a></span> &nbsp;&nbsp;
                    <span><a href="" title="Join in setting/reviewing Test Questions,"> <i class="fa fa-angle-double-right"> </i>Join Curriculum Team</a></span>
                </div>
            </div>
        </div></div>

    <!--School Search Form Starts-->
    <div class="row"><div class="col-md-10 col-md-offset-1 ">
            <form class="form-horizontal">
                <div class="row">
                <div class="col-md-3">
                    <div class="input-group">
                        <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-map-marker"> </i> State </span>
                        <select type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
                            <option>Imo</option>
                            <option>Rivers (PH)</option>
                            <option>Bayelsa</option>
                        </select>
                    </div>
                </div><div class="col-md-3">
                        <div class="input-group">
                            <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-globe"> </i> LGA </span>
                            <select type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
                                <option>Owerri</option>
                                <option>Ngor Okpala </option>
                                <option>Aboh Mbaise</option>
                                <option>All</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="input-group">
                            <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-gift"> </i> Facility </span>
                            <select type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
                                <option>School-Bus</option>
                                <option>Internet enabled-Computer Lab</option>
                                <option>well-equiped Science Lab/Library</option>
                                <option>Borden school</option>
                            </select>
                        </div>
                    </div> <div class="col-md-3">
                        <div class="input-group">

                            <input type="submit" name="submit" value="Search" class="btn btn-group-lg form-control btn-info">
                            <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-zoom-in"> </i></span>
                        </div>

                        </div> </div>
</form>
        </div>
    </div><hr style="padding-bottom: 0; margin-bottom: 0" width="50%">
    <!-- Write ups of school Awards Begin -->
    <div class="row"><div class="col-md-10 col-md-offset-1">
            <div class="row">
                <div class="col-md-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">School/Teacher Ratings</div>
<div class="panel-body">
    For A school to appear in our recommended list, It must be rated high by student, Parent and the Public.
                            While the Public Opinion carries 1 Star, Parents' and Students' rating carries 3 stars.
                            so its left for each school to attract these ratings. <a href=""> To rate a School, Click Here</a><hr>

                        Best Teachers Award is an Annual event where good teachers are celebrated in order to encourage them to achieve our aim of Better and quality education in the State.
                        For we think that if teachers are good, students will groomed and the society will be good. So we want to identify and honor those teachers who are the fulcrums of their schools.
                        <a href=""> To rate a teacher, Click Here</a><hr>
Good Students Award is another annual event organized by Goodschools.edu and its sponsors. To qualify, A student must meet the following criteria: Be <span title="as a proof: must have signed-up in this website and rate a school or teacher"></span>Internet Literate, Participate in our online and offline Quiz, and be rated by his Teachers and the Public.                     </div>
                <a href="" >To Rate a Student Click here.</a>

</div>  </div>                      <!-- Adverts Starts -->
                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">Sponsored Adverts</div>
                        <div class="panel-body">
                            <table class="table table-responsive">
                                <tr><td>Logo/Item Image</td><td>Item Description, Company Contact</td></tr>
                                <tr><td>Logo/Item Image</td><td>Item Description, Company Contact</td></tr>
                                <tr><td>Logo/Item Image</td><td>Item Description, Company Contact</td></tr>
                                <tr><td>Logo/Item Image</td><td>Item Description, Company Contact</td></tr>
                                <tr><td>Logo/Item Image</td><td>Item Description, Company Contact</td></tr>
                            </table>
                </div>
            </div>
                </div>
                <img alt="goodschools.edu" src="/src/img/Untitled.png" class="img img-responsive img-thumbnail">
                </div>
                    </div>
        </div>

    <!-- Featured schools -->
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="row">
                <div class="col-md-3">
                     </div>                      <!-- Adverts Starts -->
                <div class="col-md-3">

                        </div>
                <div class="col-md-3">
                </div>                      <!-- Adverts Starts -->
                <div class="col-md-3">

                </div>
                </div>
          <marquee behavior="alternate"> <img src="/src/img/featured.png" class="img img-responsive"></marquee>
        </div>
        </div>
    <!-- Write ups of school Awards Begin -->
    <div class="row"><div class="col-md-10 col-md-offset-1">
            <div class="row">
                <div class="col-md-4">
                    <h2>Contact Us</h2>
                    <form><div class="form-group">
                  <div class="input-group">
                                    <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-user"> </i></span>
                                    <input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1" required>

                                </div></div>
                          <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-envelope"> </i></span>
                                    <input type="text" class="form-control" placeholder="Your e-Mail or/and Phone" aria-describedby="basic-addon1">

                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-bullhorn"> </i></span>
                                    <input type="text" class="form-control" placeholder="Subject matter" aria-describedby="basic-addon1">

                                </div>
                            </div> <div class="form-group">
                                <div class="input-group">
                                    <textarea class="form-control" placeholder="The Message: Complain, Suggestion, Request, etc"></textarea>

                                </div> </div>  <hr>
 <input type="submit" name="submit" value="Search" class="btn btn-group-lg form-control btn-info">

                    </form>
 </div>
                <!-- Adverts Starts -->
                <div class="col-md-8">
                    <h2>About Us</h2>
                    This is a website that brings private (and few prominent public schools) together in a comparative mode such that Parents (or Guardians) can select a good school most suitable for their children.
                    This Comparism will drive schools to improve on their offerings, resulting in Quality education in the State. The site will also run some free services that will attract students and the citizens to the site.

                    <h2>The Purpose</h2>
                  To  achieve a Better and quality education in the State.
                    <h2>The Creed</h2>
                    Good Teachers make good schools. Good Schools produce great students. great students leads the Nation to greater heights.
                    <h2>Vision</h2>
                  To produce National Presidents, Ministers, Senators, Chairman of Ecowas, IMF, WAEC, WorldBAnk Country directors and much more, Through this initiative.
    </div>
    </div>
        </div>
    </div>
</div>
@endsection
