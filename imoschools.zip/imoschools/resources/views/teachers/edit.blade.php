@extends('layouts.teacherMaster')
@Section('title')
School Registration
@endsection
@section('content')
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">Display</li>
    </ol>
    <div class="row">

        <div class="col-lg-12 margin-tb">

            <div class="pull-left">

                <h2>Edit School</h2>

            </div>

        </div>

    </div>
    @if (count($errors) > 0)

        <div class="alert alert-danger">

            <strong>Whoops!</strong> There were some problems with your input.<br><br>

            <ul> @foreach ($errors->all() as $error)

                    <li>{{ $error }}</li>

                @endforeach

            </ul>

        </div>

    @endif
    {{Form::model($teachers, ['method' => 'PATCH','route' => ['teachers.update', $teachers->id]])}}
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Teacher Name:</strong>
                {{ Form::text('teacherName', null, array('placeholder' => 'Title','class' => 'form-control')) }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>gender:</strong>
                {{ Form::textarea('gender', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px')) }}
            </div></div></div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Phone:</strong>
                {{ Form::text('phone', null, array('placeholder' => 'Title','class' => 'form-control')) }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Subjects:</strong>
                {{ Form::textarea('subjects', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px')) }}
            </div></div></div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Comment:</strong>
                {{ Form::text('comment', null, array('placeholder' => 'Title','class' => 'form-control')) }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>isID:</strong>
                {{ Form::textarea('isID', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px')) }}
            </div></div></div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Current Class (e.g SS2, or SS3A):</strong>
                {{ Form::text('currentclass', null, array('placeholder' => 'Title','class' => 'form-control')) }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Picture:</strong>
                {{ Form::textarea('picture', null, array('placeholder' => 'Description','class' => 'form-control','style'=>'height:50px')) }}
            </div></div></div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-6">
            <div class="form-group"><strong>Grade:</strong>
                {{ Form::text('grade', null, array('placeholder' => 'Title','class' => 'form-control')) }}
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-6">

        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </div>
    {!! Form::close() !!}

@endsection
