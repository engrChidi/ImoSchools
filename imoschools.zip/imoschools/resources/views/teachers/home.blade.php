@extends('layouts.teacherMaster')
@Section('title')
Student
@endsection
@section('content')
    <div class="jumbotron">
        <h2>welcome #Teacher Name</h2>
        <h4>There's Much you can do now that you are here. Start by uploading a beatiful or dutiful picture of your self.</h4>
      You can <a href="">Rate your School</a> or Join us in <a href=""> Quiz and Tests</a> and much more. But most importantly ensure you get people come to your page here
        to rate. If you get high rating, that shows you are a good or popular teacher. Then you will be nominated for the best teachers award. Its glorious and uplifting.Its all for you
        <h4>You can also <a href="">invite your fellow Teachers </a> to join the platform, or help and Register those who cannot. Its a true act of friendship. </h4></div>
    <div class="row">
        <div class="col-md-6">
            Adverts of people targetting Teacher
        </div>
        <div class="col-md-6">
            Other things can be here too, this side.
            <a href="">Do you like our services? Yes <-> No</a>
        </div>
    </div>
@endsection