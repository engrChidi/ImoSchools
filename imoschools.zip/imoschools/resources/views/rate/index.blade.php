@extends('layouts.rateMaster')
@Section('title')
Teacher Registration
@endsection
@section('content')

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <div class="pull-left">
        <h2>Academicians List</h2>
    </div>
    <div class="pull-right">
        <a class="btn btn-success" href="{{ route('rate.create') }}"> Create New Product</a>
    </div>



    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Rater</th>
            <th>RaterID</th>
            <th>Ratee</th>
            <th>RateeID</th>
            <th>Rate</th>
            <th>Comment</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($rate as $rating)
            <tr>
                <td>{{ ++$i }}</td>
                <td>{{ $rating->rater}}</td>
                <td>{{ $rating->raterid}}</td>
                <td>{{ $rating->ratee}}</td>
                <td>{{ $rating->rateeid}}</td>
                <td>{{ $rating->rate}}</td>
                <td>{{ $rating->comment}}</td>
                <td>
                    <a class="btn btn-info" href="{{ route('rate.show',$rating->id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('rate.edit',$rating->id) }}">Edit</a>
                    {{ Form::open(['method' => 'DELETE','route' => ['rate.destroy', $rating->id],'style'=>'display:inline']) }}
                    {{ Form::submit('Delete', ['class' => 'btn btn-danger']) }}

                    {{ Form::close() }}
                </td>
            </tr>
        @endforeach
    </table>

    {{ $rate->render() }}
@endsection