@extends('layouts.academicMaster')
@section('title')
    Display Schools
@endsection
@section('content')

    <div class="jumbotron">
        <h2>Editing Schools</h2>
        <ol class="breadcrumb text-left">
            <li><a href="#">Home</a></li>
            <li><a href="#">Schools</a></li>
            <li class="active">Teachers</li>
        </ol>

        <div class="pull-right">
            <a class="btn btn-primary" href="{{ route('rate.index') }}"> Back</a>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Rater:</strong>
                    {{ $rate->rater}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Ratee:</strong>
                    {{ $rate->ratee}}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Ratee ID:</strong>
                    {{ $rate->rateeid}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Rater ID:</strong>
                    {{ $rate->raterid}}
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Comment:</strong>
                    {{ $rate->comment}}
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Rate:</strong>
                    {{ $rate->rate}}
                </div>
            </div>
              </div>
    </div>
@endsection