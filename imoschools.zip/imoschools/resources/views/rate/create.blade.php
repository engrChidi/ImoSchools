@extends('layouts.rateMaster')
@Section('title')
School Registration
@endsection
@section('content')
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">New School</li>
    </ol>
    <h1>Create a School</h1>

    <div class="alert alert-warning"> <!-- if there are creation errors, they will show here -->
        {{ Html::ul($errors->all()) }}
    </div>
    {{ Form::open(array('route' => 'rate.store','method'=>'POST')) }}

    <div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('rater', 'The Rater') }}
                {{ Form::text('rater', null, array('class' => 'form-control')) }}
            </div>
        </div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('ratee', 'Ratee') }}
                {{ Form::text('ratee', null, array('class' => 'form-control')) }}
            </div> </div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('comment', 'Comment') }}
                {{ Form::text('comment', null, array('class' => 'form-control')) }}
            </div> </div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('raterid', 'Rater\'s ID:') }}
                {{ Form::text('raterid', null, array('placeholder' => 'Subject','class' => 'form-control','style'=>'color:blue')) }}
            </div></div></div><div class="row"><div class="col-md-6">
 <div class="form-group">
                {{ Form::label('rateeid', 'Ratee ID)') }}
                {{ Form::text('rateeid', null, array('placeholder' => 'The Current Class You Teach','class' => 'form-control','style'=>'color:blue')) }}
           </div>
    </div><div class="col-md-6">
 <div class="form-group">
                {{ Form::label('rate', 'The Rate)') }}
                {{ Form::text('rate', null, array('placeholder' => 'The Current Class You Teach','class' => 'form-control','style'=>'color:blue')) }}
            </div>
        </div>
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

    </div>
@endsection