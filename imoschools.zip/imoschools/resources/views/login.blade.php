<!doctype html>
<html>
<head>
    <title>My Login Page</title>
</head>
<body>
<a href="{{ URL::to('logout') }}" class="btn btn-success">Logout</a>"
{{ Form::open(array('url' => 'login')) }}
<h1>Login</h1>
<!-- if there are login errors, show them here -->
<p>
    {{ $errors->first('phone') }}
    {{ $errors->first('password') }}
</p>
<p>
    {{ Form::label('phone', 'Phone Number') }}
    {{ Form::text('phone', Input::old('phone'), array('placeholder' => '0807')) }}
</p>
<p>
    {{ Form::label('password', 'Password') }}
    {{ Form::password('password') }}
</p>
<p>{{ Form::submit('Submit!') }}</p>
{{ Form::close() }}
</body>
</html>
