@extends('layouts.studentsMaster')
@Section('title')
Student
@endsection
@section('content')
<div class="jumbotron">
    <h2>welcome #student Name</h2>
    <h4>There's Much you can do now that you are here</h4>
    Do them to better your future. There are <a href="">Downloads</a> containing, Quiz, tutorials, tests, Exam Past Questions and more. Its all for you
<h4>You can also <a href=""> your Friend </a> to join the platform, or help and Register those who cannot. Its a true act of friendship. </h4></div>
<div class="row">
    <div class="col-md-6">
       Adverts of people that are students favorite
    </div>
    <div class="col-md-6">
        Other things can be here too, this side.
    </div>
</div>
@endsection