@extends('layouts.app')
@Section('title')
School Registration
@endsection
@section('content')
    <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">Schools</a></li>
        <li class="active">New School</li>
    </ol>
    <h1>Create a School</h1>

    <div class="alert alert-warning"> <!-- if there are creation errors, they will show here -->
        {{ Html::ul($errors->all()) }}
    </div>
    {{ Form::open(array('route' => 'students.store','method'=>'POST','files'=>true)) }}

    <div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('studentName', 'Teacher Name') }}
                {{ Form::text('studentName', null, array('class' => 'form-control')) }}
            </div>
        </div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('phone', 'Phone Number') }}
                {{ Form::text('phone', null, array('class' => 'form-control')) }}
            </div> </div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('level', 'Level') }}
                {{ Form::text('level', null, array('class' => 'form-control')) }}
            </div> </div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('dob', 'DateOfBirth (just Month & Day') }}
                {{ Form::text('dob', null, array('placeholder' => 'e.g 24/07','class' => 'form-control','style'=>'color:blue')) }}
            </div></div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('gender', 'Gender:') }}
                {{ Form::select('gender', ['Male','Female'], null, array('class'=>'form-control'))}}
            </div></div><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('isID', 'Your SchoolID: (get it Here)') }}
                {{ Form::text('isID', null, array('placeholder' => 'Your School ID','class' => 'form-control','style'=>'color:blue')) }}
            </div></div></div><div class="row"><div class="col-md-6">
            <div class="form-group">
                {{ Form::label('img', 'Picture') }}
                {{Form::file('img', array('class' => 'form-control')) }}
            </div></div><div class="col-md-6">efef</div></div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

    </div>
@endsection