@extends('layouts.studentsMaster')
@Section('title')
Teacher Registration
@endsection
@section('content')

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif;
    <div class="pull-left">
        <h2>Teacher List</h2>
    </div>
    <div class="pull-right">
        <a class="btn btn-success" href="{{ route('students.create') }}"> Create New Students</a>
    </div>
 <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Students Name</th>
            <th>Phone </th>
            <th>Subjects</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($students as $student)
            <tr>
                <td>{{ ++$i }}</td>
                <td>{{ $student->studentName}}</td>
                <td>{{ $student->phone}}</td>
                <td>{{ $student->gender}}</td>
                <td> <a href='{{ asset("img/$student->img") }}'>{{ $student->img }}</a></td>
                <td>
                    <a class="btn btn-info" href="{{ route('students.show',$student->id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('students.edit',$student->id) }}">Edit</a>
                    {{ Form::open(['method' => 'DELETE','route' => ['students.destroy', $student->id],'style'=>'display:inline']) }}
                    {{ Form::submit('Delete', ['class' => 'btn btn-danger']) }}
                    {{ Form::close() }}
                </td>
            </tr>
        @endforeach
    </table>

    {{ $students->render() }}
@endsection