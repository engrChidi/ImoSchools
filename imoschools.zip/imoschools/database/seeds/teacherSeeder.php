<?php
use App\Teachers;
use Illuminate\Database\Seeder;

class teacherSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $teacher = new Teachers([
            'teachername' =>'Obiora joe',
            'grade'=>'40%',
            'picture' => '\src\img\sclogo.jpg',
            'currentclass' =>'SS3',
            'subjects' => 'maths, Agric',
            'phone' => '08064747096',
            'gender' => 'Male',
            'comment'=>'this',
        'isID'=>'thats'
        ]);
        $teacher->save();
    }
}
