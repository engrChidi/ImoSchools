<?php

use Illuminate\Database\Seeder;
use App\Rate;
class RateSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $rate = new Rate([
            'rater'=>'student',
            'ratee'=>'teacher',
            'raterid'=>'5',
            'rateeid'=>'8',
            'rate'=>'4 star',
            'comment'=>'trying'
        ]);
        $rate->save();   //
    }
}
