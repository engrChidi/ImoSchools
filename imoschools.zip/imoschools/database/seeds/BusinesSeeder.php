<?php
use App\Business;
use Illuminate\Database\Seeder;

class BusinesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $business = new Business([
            'Username' =>'Mr. Obi',
            'location'=>'Umungazi, NgorOkpala LGA, Imo State',
            'image' => '\src\img\sclogo.jpg',
            'product' =>'Red and White with Brown Sandals',
            'phone' => '08064747',
            'comment' => 'Learning, Knowledge and Power. The keys to nation Building',
            'businessName'=>'Tamva'
        ]);
        $business->save();
    }
}
