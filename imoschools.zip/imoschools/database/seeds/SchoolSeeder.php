<?php

use Illuminate\Database\Seeder;
use App\Schools;

class SchoolSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $school = new Schools([
           'schoolname' =>'Obis big School',
            'address'=>'Umungazi, NgorOkpala LGA, Imo State',
        'logo' => '\src\img\sclogo.jpg',
        'color' =>'Red and White with Brown Sandals',
        'motto' => 'Learning, Knowledge and Power. The keys to nation Building',
        'phone' => '08064747096',
            'email' => 'myschollname@server.tld',
            'website'=>'www.mysachool.com',
        'facilities' =>'Toliet, Field, Bus',
        'strongPoints' =>'Qualified Teachers',
        'upcomingEvent' =>'RegistrationOnGoing',
        'comment' => 'we take good care of children',
        'admissionRequirements' => 'school uniform, PTA levy, Brown Sandals, etc',
        'schoolfees' =>'45,000 Naira'
        ]);
        $school->save();
        //
    }
}
