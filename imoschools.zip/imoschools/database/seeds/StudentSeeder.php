<?php
use App\Students;
use Illuminate\Database\Seeder;

class StudentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $students = new Students([
            'studentName'=>'Prof. Okere',
            'isID'=>'15',
            'level'=>'SS1',
            'gender'=>'Male',
            'img'=>'src/img/paper1.jpeg',
            'phone'=>'09073562890',
            'dob'=>'20/May',
            'rate'=>'good'
        ]);
        $students->save();   //
    }
}
