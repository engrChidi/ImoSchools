<?php
use App\Login;
use Illuminate\Database\Seeder;

class LoginSeeder extends Seeder
{

    public function run()
    {
        $login = new Login([
        'username' => 'sevilayha',
        'phone'    => '08076565434',
        'password' => Hash::make('awesome'),
        ]);
        $login->save();
    }
}
