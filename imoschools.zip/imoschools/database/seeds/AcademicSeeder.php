<?php

use Illuminate\Database\Seeder;
use App\Academics;

class AcademicSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      $academics = new Academics([
          'userName'=>'Prof. Okere',
          'qualification'=>'PHD',
          'lga'=>'Njaba',
          'subject'=>'physics',
          'uploadQuestion'=>'src/img/paper1.jpeg',
          'phone'=>'09073562890',
          'comment'=>'obj Questions'
      ]);
        $academics->save();
    }
}
