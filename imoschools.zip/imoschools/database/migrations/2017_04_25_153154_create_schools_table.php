<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSchoolsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('schools', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->string('schoolname');
            $table->string('address');
            $table->string('logo');
            $table->string('color');
            $table->text('motto');
            $table->string('phone');
            $table->string('email');
            $table->string('website');
            $table->text('facilities');
            $table->text('strongPoints');
            $table->text('upcomingEvent');
            $table->text('comment');
            $table->text('lga');
            $table->text('schoolfees');

                  });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('schools');
    }
}
